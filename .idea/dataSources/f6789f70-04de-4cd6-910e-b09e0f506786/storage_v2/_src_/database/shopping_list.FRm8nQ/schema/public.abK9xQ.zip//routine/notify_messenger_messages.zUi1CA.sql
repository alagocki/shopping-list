create function notify_messenger_messages() returns trigger
    language plpgsql
as
$$
            BEGIN
                PERFORM pg_notify('messenger_messages', NEW.queue_name::text);
                RETURN NEW;
            END;
        $$;

alter function notify_messenger_messages() owner to shopping_list;

